# Liberalia Photobooth Plugin
